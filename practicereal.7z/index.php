<!DOCTYPE html>
<?Php session_start() ?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="email.php" method="GETS">
            First Name: <input type="text" name="fname"><br>
            <input type="submit">
        </form>
    </body>
</html>
