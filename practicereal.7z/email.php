<!DOCTYPE html>
<?php
session_start();
#super global

print_r($_GET);
var_dump($_REQUEST);
print_r($_POST);

if (isset($_SESSION['first_name'])){
    $name = $_SESSION('first_name');
}


$name = $_GET['fname'];
if (strlen($name) == 0) {
    echo "empty first name.";
    //send back to homepage
   header("location: index.php");
    exit;
    
} else {
}
    ?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        Hello <?php echo $name; ?>
        <form action="phone.php" method="GETS">
            Email: <input type="text" name="email"><br>
            <input type="submit">
        </form>
    </body>
</html>
