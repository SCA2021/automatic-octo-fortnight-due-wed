<!DOCTYPE html>
<?php session_start(); 
var_dump($_SESSION);
var_dump($_GET);
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        // put your code here
        ?>
    </body>
</html>
