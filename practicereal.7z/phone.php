<?php
session_start();
#super global

print_r($_GET);
var_dump($_REQUEST);
print_r($_POST);
var_dump($_SESSION);

$_SESSION = $_GET['email'];

//$name = $_GET['fname'];
//if (empty($name)) {
//    echo "empty first name.";
//    //send back to homepage
//    header("location: index.php");
//    exit;
//} else {
//    $_SESSION["first_name"]= $name;
//}

$email = $_GET['email'];
if (!str_contains($email, "@")) {
    header("location: email.php");
    exit;
}
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="summary.php" method="GETS">
            Phone Num: <input type="text" name="phone"><br>
            <input type="submit">
        </form>
    </body>
</html>
